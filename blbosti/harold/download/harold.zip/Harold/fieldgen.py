import objects as objs
import constants
import random as rnd


class FieldGen(object):

    @staticmethod
    def generate():
        num = rnd.random()
        if num < constants.OBSTACLE_PROB:
            return objs.Obstacle()
        elif num < (constants.OBSTACLE_PROB + constants.CHEESE_PROB):
            return objs.Cheese()
        else:
            return objs.Empty()

    @staticmethod
    def generate_empty():
        return objs.Empty()
 