#!/usr/bin/env python2
import random
import time
import pygame
import sys
import os
import pickle
from pygame.locals import *
from pygame.color import *
from constants import *
import mapobj

pygame.init()
mainClock = pygame.time.Clock()
pygame.display.set_caption('Mouse Run')
pygame.mixer.init()
pygame.mixer.music.load('zvuknapozadi.ogg')
pygame.mixer.music.play(-1, 0.0)
pygame.mixer.music.set_volume(0.5)
failSound = pygame.mixer.Sound('fail.ogg')

class UserData:
  def __init__(self):
    self.money = 0
    self.highScore = 0
    self.moneyIncrement = 1
    self.scoreIncrement = 1
    self.defaultLives = 3
    self.moneyIncrementCost = 400
    self.scoreIncrementCost = 300
    self.defaultLivesIncrCost = 250

  def incr_money(self):
    self.money += self.moneyIncrement
    print "called"

  def incr_score(self):
    self.score = self.scoreIncrement

  def buy_money_boost(self):
    if (self.money < self.moneyIncrementCost): raise Exception("Prilis drahy tovar")
    self.moneyIncrement *= 2
    self.moneyIncrementCost = (int(self.moneyIncrementCost**0.5)+8)**2

  def buy_score_boost(self):
    if (self.money < self.scoreIncrementCost): raise Exception("Prilis drahy tovar")
    self.scoreIncrement *= 2
    self.moneyIncrementCost = (int(self.moneyIncrementCost**0.5)+5)**2

  def buy_lives_boost(self):
    if (self.money < self.defaultLivesIncrCost): raise Exception("Prilis drahy tovar")
    self.defaultLives += 1
    self.defaultLivesIncrCost = (int(self.moneyIncrementCost**0.5)+4)**2

class Button:
  def __init__(self, inState="GAME"): #z obchodu pojde do hry
    self.returnState = inState
    self.textOnButton = inState
    pygame.font.init()
    self.font = pygame.font.Font("./RUBBBB__.TTF", 30)
    self.text = self.font.render("CLICK TO ENTER THE "+str(self.returnState), True,  Color("White"), Color("Purple"))
    self.rect = self.text.get_rect()
    self.rect.topleft = windowSurface.get_rect().topleft
  
  def draw(self):
    windowSurface.blit(self.text, self.rect)
  
  def isClicked(self, event):
    if event.pos[0] < self.rect.right and event.pos[0] > self.rect.left and event.pos[1] < self.rect.bottom and event.pos[1] > self.rect.top:
      return True
    return False
  

class Score:
  def __init__(self, money, highScore):
    pygame.font.init()
    font_path = "./RUBBBB__.TTF"
    font_size = HEIGHT_OF_FONT
    self.font = pygame.font.Font(font_path, font_size)
    self.highscore = highScore
    self.actualScore = 0
    self.lives = 0
    self.textik = self.font.render("Money " + str(money) + "   Score "+str(self.actualScore)+"   Highscore "+str(self.highscore)+" Lives "+str(self.lives), True, Color("yellow"))
    self.textRect = self.textik.get_rect()
    self.textRect.top = windowSurface.get_rect().top
    self.textRect.right = windowSurface.get_rect().right
    
  def setScore(self, money, newScore, newLives, userDataObj):
    self.actualScore=newScore
    self.lives = newLives
    if(self.actualScore > self.highscore):
      self.highscore = self.actualScore
      userDataObj.highScore = self.highscore
    self.textik = self.font.render("Money " + str(money) + "   Score "+str(self.actualScore)+"   Highscore "+str(self.highscore)+" Lives "+str(self.lives), True, Color("yellow"))
    self.textRect = self.textik.get_rect()
    self.textRect.top = windowSurface.get_rect().top
    self.textRect.right = windowSurface.get_rect().right
    windowSurface.blit(self.textik, self.textRect)

class MenuState:
  def __init__(self):
    pygame.font.init()
    self.font_path = "./RUBBBB__.TTF"
    self.font_size = 67
    self.basicFont = pygame.font.Font(self.font_path, self.font_size)
    self.text = self.basicFont.render("Click left to Continue", True, Color("Black"))
    self.textRect = self.text.get_rect()
    self.textRect.centerx = windowSurface.get_rect().centerx
    self.textRect.centery = windowSurface.get_rect().centery
    
  def process_event(self, event):
    if event.type == MOUSEBUTTONDOWN and event.button == LEFT:
      return "GAME"
    if event.type == MOUSEBUTTONDOWN and event.button == RIGHT:
      return "ENDGAME"
    if event.type == QUIT:
      pygame.quit()
      sys.exit()
    else:
      return ""
    
  def update(self):
    return ""
  
  def reset(self):
    pygame.mouse.set_visible(True)
  
  def draw(self):
    windowSurface.fill(Color("yellow"))
    windowSurface.blit(self.text, self.textRect)


class GameState:
  def __init__(self):
    try:
      dataFile = open(DATA_PATH, 'rb')
      self.userData = pickle.load(dataFile)
      dataFile.close()
      self.dataFile = open(DATA_PATH, 'wb') # for write
    except:
      self.dataFile = open(DATA_PATH, 'wb')
      self.userData = UserData()
      pickle.dump(self.userData, self.dataFile)

    self.score = Score(self.userData.money, self.userData.highScore)
    self.__mapa = mapobj.Map()
    self.zacina = False
    self.itt = 0
  
  def process_event(self, event):
    if event.type == MOUSEBUTTONDOWN and event.button == LEFT:
      pickle.dump(self.userData, self.dataFile)
      return "PAUSE"
    #if event.type == MOUSEBUTTONDOWN and event.button == RIGHT:
      #pickle.dump(self.userData, self.dataFile)
      ##self.dataFile.close()
      #return "ENDGAME"
    return None
  
  def draw(self):
    self.score.setScore(self.userData.money, self.__mapa.mouse.score_counter.value,
                        self.__mapa.mouse.num_of_lives(), self.userData)
    self.__mapa.draw()
  
  def reset(self):
    if self.zacina:
      return 0
    self.zacina = True
    del self.__mapa
    self.__mapa = mapobj.Map()
    self.score.actualScore = 0
    #start hry
    windowSurface.fill(Color("Black"))
    self.draw()
    pygame.display.flip()
    self.zacina = False
      
  def update(self):
    self.poz = pygame.mouse.get_pos()
    y = self.poz[1] - HEIGHT_OF_FONT
    if WIDTH_OF_FIELD_PX * self.__mapa.mouse.position > y and self.__mapa.mouse.position > 0 and WIDTH_OF_FIELD_PX * self.__mapa.mouse.position - y > WIDTH_OF_FIELD_PX/2:
      self.__mapa.move_mouse(self.__mapa.mouse.position-1, self.userData)
    elif WIDTH_OF_FIELD_PX * self.__mapa.mouse.position < y and self.__mapa.mouse.position < FIELDS_IN_ROW-1 and -WIDTH_OF_FIELD_PX * self.__mapa.mouse.position + y > WIDTH_OF_FIELD_PX/2:
      self.__mapa.move_mouse(self.__mapa.mouse.position+1, self.userData)
    if(self.itt==0):
      self.__mapa.update()
    self.itt+=1
    self.itt=self.itt%VELOCITY
    self.__mapa.move_mouse(self.__mapa.mouse.position, self.userData)
    if self.__mapa.mouse.is_dead():
      self.dataFile = open(DATA_PATH, "wb")
      pickle.dump(self.userData, self.dataFile)
      self.dataFile.close()
      return "LOST"
    return None


class PauseState:
  def __init__(self):
    pygame.font.init()
    self.font_path = "./RUBBBB__.TTF"
    self.font_size = 32
    self.font = pygame.font.Font(self.font_path, self.font_size)
    self.text = self.font.render("PAUSE", True, Color("red"))
    self.podtext = self.font.render("Click Left to Continue", True, Color("red"))
    self.textRect = self.text.get_rect()
    self.podtextRect = self.podtext.get_rect()
    self.textRect.centerx = windowSurface.get_rect().centerx
    self.textRect.centery = windowSurface.get_rect().centery
    self.podtextRect.centerx = windowSurface.get_rect().centerx
    self.podtextRect.top = self.textRect.bottom
  
  def process_event(self,event):
    if event.type == MOUSEBUTTONDOWN and event.button == LEFT:
      return "GAME"
    if event.type == MOUSEBUTTONDOWN and event.button == RIGHT:
      return "ENDGAME"
    return None
  
  def update(self):
    return None
  
  def draw(self):
    windowSurface.blit(self.text, self.textRect)
    windowSurface.blit(self.podtext, self.podtextRect)


class EndGameState:
  def __init__(self):
    pygame.font.init()
    self.font_path = "./RUBBBB__.TTF"
    self.font_size = 32
    self.font = pygame.font.Font(self.font_path, 50)
    self.fontik = pygame.font.Font(self.font_path, self.font_size)
  
  def ukonciHru(self, hs = 0):
    self.t = 4
    while self.t > 0:
      self.text = self.font.render("Your highscore was "+ str(hs), True, Color("red"))
      self.podtext = self.font.render("Game ends in "+str(self.t), True, Color("yellow"))
      self.textRect = self.text.get_rect()
      self.podtextRect = self.podtext.get_rect()
      self.textRect.centerx = windowSurface.get_rect().centerx
      self.textRect.centery = windowSurface.get_rect().centery
      self.podtextRect.centerx = windowSurface.get_rect().centerx
      self.podtextRect.top = self.textRect.bottom
      self.t-=1
      windowSurface.fill(Color("black"))
      windowSurface.blit(self.text, self.textRect)
      windowSurface.blit(self.podtext, self.podtextRect)
      pygame.display.flip()
      time.sleep(1)
    pygame.quit()
    sys.exit()
  
  def reset(self):
    pygame.mouse.set_visible(True)
  
  def process_event(self,event):
    if event.type == MOUSEBUTTONDOWN and event.button == LEFT:
      return stav_bef
    if event.type == MOUSEBUTTONDOWN and event.button == RIGHT:
      self.ukonciHru(stavy["GAME"].score.highscore)
      return None
    return None
  
  def update(self):
    return ""
  
  def draw(self):
    self.text = self.font.render("Click right to end", True, Color("brown"))
    self.textRect = self.text.get_rect()
    self.textRect.centerx = windowSurface.get_rect().centerx
    self.textRect.centery = windowSurface.get_rect().centery
    windowSurface.blit(self.text, self.textRect)
  

class LostState: #ked mys sa chyti do pasce a bud bude hrat zas alebo ho to da na ENDGAME dokodim
  def __init__(self, score=0, highscore=0):
    pygame.font.init()
    self.font_path = "./RUBBBB__.TTF"
    self.font_size = 42
    self.fontisko = pygame.font.Font(self.font_path, self.font_size)
    self.fontik = pygame.font.Font(self.font_path, 22)
    self.font = pygame.font.Font(self.font_path, 32)
    self.button = Button("STORE")
  
  def process_event(self,event):
    if event.type == MOUSEBUTTONDOWN and event.button == LEFT:
      if self.button.isClicked(event):
	return self.button.returnState
      stavy["GAME"].reset()
      return "GAME"
    if event.type == MOUSEBUTTONDOWN and event.button == RIGHT:
      return "ENDGAME"
    return None
  
  def reset(self):
    pygame.mouse.set_visible(True)
  
  def update(self):
    return ""
  
  def draw(self):
    self.text = self.fontisko.render("LOST", True, Color("red"))
    strg = "Score "+str(stavy["GAME"].score.actualScore)+ "    Highscore "+str(stavy["GAME"].score.highscore)
    self.scoreInfo = self.fontik.render(strg, True, Color("yellow"))
    self.podtext = self.font.render("Click Left to Continue, Right to End Game", True, Color("brown"))
    self.textRect = self.text.get_rect()
    self.podtextRect = self.podtext.get_rect()
    self.scoreInfoRect = self.scoreInfo.get_rect()
    self.textRect.centerx = windowSurface.get_rect().centerx
    self.textRect.centery = windowSurface.get_rect().centery
    self.scoreInfoRect.centerx = windowSurface.get_rect().centerx
    self.scoreInfoRect.top = self.textRect.bottom
    self.podtextRect.centerx = windowSurface.get_rect().centerx
    self.podtextRect.top = self.scoreInfoRect.bottom
    windowSurface.blit(self.text, self.textRect)
    windowSurface.blit(self.podtext, self.podtextRect)
    windowSurface.blit(self.scoreInfo, self.scoreInfoRect)
    self.button.draw()


class StoreState:
  def __init__(self):
    pygame.font.init()
    self.font_path = "./RUBBBB__.TTF"
    self.font_size = HEIGHT_OF_FONT
    self.fontisko = pygame.font.Font(self.font_path, self.font_size)
    self.fontik = pygame.font.Font(self.font_path, 22)
    self.font = pygame.font.Font(self.font_path, 32)
    self.button = Button("GAME") #tymto tlacidlom sa hrac dostane spat do hry
  
  def process_event(self, event): #tu si dopln spracovanie ostatnych eventov
    if event.type == MOUSEBUTTONDOWN and event.button == LEFT:
      if self.button.isClicked(event):
	stavy["GAME"].reset()
	return self.button.returnState
  
  def update(self): #co sa robi kazdy krok
    self.userData = pickle.load(open(DATA_PATH, 'rb'))
  
  def draw(self): #co sa vykresluje
    self.text_money = self.fontisko.render("YOUR MONEY - " + str(self.userData.money), True, Color("yellow"))
    self.text_item1 = self.fontisko.render("MONEY BOOST - " + str(self.userData.moneyIncrementCost), True, Color("yellow"), Color("purple"))
    self.text_item2 = self.fontisko.render("SCORE BOOST - " + str(self.userData.scoreIncrementCost), True, Color("yellow"), Color("purple"))
    self.text_item3 = self.fontisko.render("MORE LIVES - " + str(self.userData.defaultLivesIncrCost), True, Color("yellow"), Color("purple"))
    self.text_money_rect = self.text_money.get_rect()
    self.text_item1_rect = self.text_item1.get_rect()
    self.text_item2_rect = self.text_item2.get_rect()
    self.text_item3_rect = self.text_item3.get_rect()
    self.text_money.get_rect().centerx = windowSurface.get_rect().centerx
    self.text_money.get_rect().centery = windowSurface.get_rect().centery-40
    self.text_item1.get_rect().centerx = windowSurface.get_rect().centerx
    self.text_item1.get_rect().top = self.text_money.get_rect().bottom
    self.text_item2.get_rect().centerx = windowSurface.get_rect().centerx
    self.text_item2.get_rect().top = self.text_item1.get_rect().bottom
    self.text_item3.get_rect().centerx = windowSurface.get_rect().centerx
    self.text_item3.get_rect().top = self.text_item1.get_rect().bottom
    self.text_money_rect.centerx = windowSurface.get_rect().centerx
    self.text_money_rect.centery = windowSurface.get_rect().centery-40
    self.text_item1_rect.centerx = windowSurface.get_rect().centerx
    self.text_item1_rect.top = self.text_money_rect.bottom
    self.text_item2_rect.centerx = windowSurface.get_rect().centerx
    self.text_item2_rect.top = self.text_item1_rect.bottom
    self.text_item3_rect.centerx = windowSurface.get_rect().centerx
    self.text_item3_rect.top = self.text_item1_rect.bottom
    windowSurface.blit(self.text_money, self.text_money_rect)
    windowSurface.blit(self.text_item1, self.text_item1_rect)
    windowSurface.blit(self.text_item2, self.text_item2_rect)
    windowSurface.blit(self.text_item3, self.text_item3_rect)
    self.button.draw()
  

stav_bef = "MENU" 
stav = "MENU"

stavy = {"MENU":MenuState(),
	 "GAME":GameState(),
	 "ENDGAME":EndGameState(),
	 "PAUSE":PauseState(),
	 "LOST":LostState(),
	 "STORE":StoreState()
  }

while True:
  pygame.display.update()
  for event in pygame.event.get():
    if event.type == QUIT:
      pygame.quit()
      sys.exit()
    if event.type == KEYDOWN:
      pygame.quit()
      sys.exit()
    next_state = stavy[stav].process_event(event)
    if next_state!="" and next_state != None:
      stav_bef=stav
      stav = next_state
      if next_state == "LOST":
	pygame.mixer.music.set_volume(0.1)
	failSound.play()
      else:
	pygame.mixer.music.set_volume(0.4)
      if next_state=="GAME":
	time.sleep(0.5)
  next_state = stavy[stav].update()
  if next_state != "" and next_state != None:
    stav_bef=stav
    if next_state == "LOST":
      pygame.mixer.music.set_volume(0.1)
      failSound.play()
    else:
      pygame.mixer.music.set_volume(0.4)
    stav = next_state
    if next_state=="GAME":
      time.sleep(0.5)
  
  
  windowSurface.fill(Color("Black"))
  stavy[stav].draw()
  pygame.display.flip()
  mainClock.tick(FPS)
  