import constants
import row
import mouse
import fieldgen
import pygame
import random
from objects import Empty

class Map(object):

    def __init__(self):
        pygame.mixer.init()
        self.__list_of_rows = []
        self.__mouse = mouse.Mouse()
        self.img_pasca= pygame.image.load('pasca.png').convert_alpha()
        self.img_mys1= pygame.image.load('mys1.png').convert_alpha()
        self.img_mys2= pygame.image.load('mys2.png').convert_alpha()
        self.img_syr= pygame.image.load('syr.png').convert_alpha()
        self.img_pozadie= pygame.image.load('pozadie.png').convert_alpha()
        self.hryz = [pygame.mixer.Sound('hryzkratky.ogg'), pygame.mixer.Sound('a.ogg'), pygame.mixer.Sound('b.ogg'), pygame.mixer.Sound('c.ogg')]
        for sound in self.hryz:
            sound.set_volume(1)
        self.pasca = pygame.mixer.Sound('pasca.ogg')
        self.pasca.set_volume(1)
        self.mysAnim = 0
        for ri in range(0, constants.NUMBER_OF_ROWS):
            self.add_row(function=fieldgen.FieldGen.generate_empty, remove_first=False)

    def __getitem__(self, item):
        return self.__list_of_rows[item]
    
    def add_row(self, function=None, remove_first=True):
        new_row = row.Row(function=function)
        if remove_first:
            del self.__list_of_rows[0]
        self.__list_of_rows.append(new_row)

    def get_mouse_row(self):
        return self.__list_of_rows[0]

    def move_mouse(self, position, userDataObj):
        self.__mouse.position = position
        field = self.get_mouse_row()[position]
        if field.is_empty():
            # ...
            pass
        elif field.is_cheese():
            if field.eaten == False:
             self.__mouse.score_counter.incr()
             field.eaten = True
             self.hryz[random.randint(0, 3)].play()
             userDataObj.incr_money()
        elif field.is_obstacle():
            if field.sklapla == False:
                self.pasca.play()
                self.__mouse.die()
                field.sklapla = True
        else:
            # ...
            pass

    @property
    def mouse(self):
        return self.__mouse

    #@mouse.setters
    #def mouse(self, new_val):
        #raise NotImplementedError("Menit mys nemozte")
    
    def update(self):
      self.add_row(function=fieldgen.FieldGen.generate)
      novo_pridany_riadok = self.get_mouse_row()
      
    
    def draw(self):
        for i in range(0, constants.NUMBER_OF_ROWS):
            aktSirka = 0
            for policko in self.__list_of_rows[i]:
                if policko.is_cheese():
                    if policko.eaten:
                        constants.windowSurface.blit(self.img_pozadie, (i*constants.HEIGHT_OF_FIELD_PX, aktSirka*constants.WIDTH_OF_FIELD_PX+constants.HEIGHT_OF_FONT))
                    else:
                        constants.windowSurface.blit(self.img_pozadie, (i*constants.HEIGHT_OF_FIELD_PX, aktSirka*constants.WIDTH_OF_FIELD_PX+constants.HEIGHT_OF_FONT))
                        constants.windowSurface.blit(self.img_syr, (i*constants.HEIGHT_OF_FIELD_PX, aktSirka*constants.WIDTH_OF_FIELD_PX+constants.HEIGHT_OF_FONT))
                elif policko.is_obstacle():
                    constants.windowSurface.blit(self.img_pozadie, (i*constants.HEIGHT_OF_FIELD_PX, aktSirka*constants.WIDTH_OF_FIELD_PX+constants.HEIGHT_OF_FONT))
                    constants.windowSurface.blit(self.img_pasca, (i*constants.HEIGHT_OF_FIELD_PX, aktSirka*constants.WIDTH_OF_FIELD_PX+constants.HEIGHT_OF_FONT))
                else:
                    constants.windowSurface.blit(self.img_pozadie, (i*constants.HEIGHT_OF_FIELD_PX, aktSirka*constants.WIDTH_OF_FIELD_PX+constants.HEIGHT_OF_FONT))
                aktSirka+=1
        if(self.mysAnim%4 < 2):
            constants.windowSurface.blit(self.img_mys2, (0, self.__mouse.position*constants.WIDTH_OF_FIELD_PX+constants.HEIGHT_OF_FONT))
        else:
            constants.windowSurface.blit(self.img_mys1, (0, self.__mouse.position*constants.WIDTH_OF_FIELD_PX+constants.HEIGHT_OF_FONT))
        self.mysAnim+=1
  



