import random
import time
import pygame
import sys
import os
from pygame.locals import *
from pygame.color import *

FIELDS_IN_ROW = 15
NUMBER_OF_ROWS = 20
HEIGHT_OF_FIELD_PX = 50
WIDTH_OF_FIELD_PX = 50

OBSTACLE_PROB = 0.2
CHEESE_PROB = 0.1

#tlacidla mysi
LEFT=1
MIDDLE=2
RIGHT=3

windowSurface = pygame.display.set_mode((1024, 768),FULLSCREEN)

FPS = 40

VELOCITY = 20
HEIGHT_OF_FONT = 32

INITIAL_LIVES = 3

DATA_PATH = "data.pkl"
