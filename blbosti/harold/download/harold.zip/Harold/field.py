import constants as cts
import random as rnd
#import objects as objs

class Field(object):

    def is_empty(self):
        return type(self).__name__ == "Empty"

    def is_obstacle(self):
        return type(self).__name__ == "Obstacle"

    def is_cheese(self):
        return type(self).__name__ == "Cheese"

