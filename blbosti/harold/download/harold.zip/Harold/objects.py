

class Empty(__import__("field").Field):
    pass

class Obstacle(__import__("field").Field):
    def __init__(self):
      self.sklapla = False

class Cheese(__import__("field").Field):
    def __init__(self):
      self.eaten = False
