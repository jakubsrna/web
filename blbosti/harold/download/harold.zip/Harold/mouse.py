import pygame
import constants
import score_counter

class Mouse(object):

    def __init__(self):
        self.__position = 0
        self.__scoreCounter = score_counter.ScoreCounter()
        self.__dead = False
        self.__lives = constants.INITIAL_LIVES

    @property
    def position(self):
        return self.__position

    @position.setter
    def position(self, new_val):
        if new_val >= constants.FIELDS_IN_ROW or new_val < 0:
            raise ValueError("Mys sa pokusa ist na neplatnu poziciu")
        self.__position = new_val
        return self.__position

    @property
    def score_counter(self):
        return self.__scoreCounter

    @score_counter.setter
    def score_counter(self, new_val):
        raise NotImplementedError("Menit objekt pocitadla nemozte")	
    
    def die(self):
	self.__lives -=1
	if self.__lives <0:
	  self.__dead = True
	  
    def num_of_lives(self):
      return self.__lives

    def is_dead(self):
        return self.__dead
        # casom to mozno bude fikanejsie