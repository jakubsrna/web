
class ScoreCounter(object):

    def __init__(self, init_value=0):
        self.__value = init_value

    def incr(self):
        self.__value += 1
        return self.__value

    @property
    def value(self):
        return self.__value

    @value.setter
    def value(self, new_val):
        raise NotImplementedError("Menit hodnotu pocitadla nemozte")