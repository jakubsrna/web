import objects as objs
import constants
import field
import fieldgen
import random as rnd

class Row(object):

    def __init__(self, function=fieldgen.FieldGen.generate, num_of_fields=constants.FIELDS_IN_ROW):
        if function == None: function = fieldgen.FieldGen.generate
        self.__list_of_fields = []
        for f_num in range(num_of_fields):
            onefield = function() 
            self.__list_of_fields.append(onefield)

    def __getitem__(self, item):
        return self.__list_of_fields[item]


    def __iter__(self):
        self.__iter_index = 0
        return self

    def next(self):
        if self.__iter_index >= len(self.__list_of_fields):
            raise StopIteration
        else:
            self.__iter_index += 1
            return self.__list_of_fields[self.__iter_index-1]
    
    @staticmethod
    def generate():
        num = rnd.random()
        if num < constants.OBSTACLE_PROB:
            return objs.Obstacle()
        elif num < (constants.OBSTACLE_PROB + constants.CHEESE_PROB):
            return objs.Cheese()
        else:
            return objs.Empty()

    @staticmethod
    def generate_empty():
        return objs.Empty()
